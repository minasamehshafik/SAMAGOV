var swiper = new Swiper(".heroSwiper", {
  autoplay: {
    delay: 3000,
    disableOnInteraction: false,
  },
  pagination: {
    el: ".heroSwiperPagination",
    clickable: true,
  },
});

document.addEventListener("DOMContentLoaded", () => {
  new WOW().init();
  // Accesibility Contrast Theme
  const darkThemeToggle = document.querySelector(".dark-theme");
  const htmlElement = document.querySelector("html");

  darkThemeToggle.addEventListener("click", () => {
    htmlElement.classList.toggle("theme-dark");
  });
  // Accessibility Font Resizing
  const fontSizeLinks = document.querySelectorAll(".font-size");
  const html = document.documentElement;
  // Check and apply stored font size
  const storedFontSize = localStorage.getItem('fontSize');
  if (storedFontSize) {
    html.classList.add(`${storedFontSize}-font`);
  }
  fontSizeLinks.forEach(link => {
    link.addEventListener('click', (event) => {
      event.preventDefault();
      const selectedSize = link.getAttribute('data-size');
      // Remove active class from all links
      fontSizeLinks.forEach(otherLink => otherLink.classList.remove('active'));
      // Add active class to the clicked link
      link.classList.add('active');
      // Remove all existing font size classes
      fontSizeLinks.forEach(link => link.classList.remove('active'));
      link.classList.add('active'); // Add active class to the clicked link

      html.classList.remove('small-font', 'medium-font', 'large-font');
      html.classList.add(`${selectedSize}-font`);

      // Store the selected font size in localStorage
      localStorage.setItem('fontSize', selectedSize);
    });
    // Check and apply stored font size on page load
    if (link.getAttribute('data-size') === storedFontSize) {
      link.classList.add('active');
    }
  });

  // Survey

  const surveyForm = document.querySelector('.survey-form');
  const surveyInfo = document.querySelector('.survey-info');
  const surveyCloseBtn = document.querySelector('.survey-close');
  const surveyButtons = document.querySelectorAll('.survey-btn');
  const surveyStatus = document.querySelector('.survey-status');
  const surveyQuestion = document.querySelector('.survey-question');
  const sendSurveyBtn = document.querySelector('.send-survey-btn');

  surveyButtons.forEach(button => {
    button.addEventListener('click', () => {
      toggleSurvey();
    });
  });

  surveyCloseBtn.addEventListener('click', () => {
    toggleSurvey();
    surveyStatus.classList.add('d-none');
    surveyQuestion.classList.remove('d-none');
  });
  sendSurveyBtn.addEventListener('click', () => {
    surveyForm.classList.remove('show-survey');
    surveyInfo.classList.remove('d-none');
    surveyStatus.classList.remove('d-none');
    surveyQuestion.classList.add('d-none');
    surveyCloseBtn.classList.add('d-none');
  });

  function toggleSurvey() {
    surveyInfo.classList.toggle('d-none');
    surveyForm.classList.toggle('show-survey');
    surveyButtons.forEach(btn => btn.disabled = !btn.disabled);
    surveyCloseBtn.classList.toggle('d-none');
  }
});


